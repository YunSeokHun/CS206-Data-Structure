def Is_Q(s):
    if ('?' in s):
        return True
    else:
        return False

def update_pre(ans, real_ans, question, pre, post, pos):
    if (pos > 0):
        pass
    else:
        for i in range(len(pre)):
            if (post[pos] == pre[i]):
                break
        pos = i
    if (ans == 'Y'):
        pre.insert(pos, real_ans)
        pre.insert(pos, question)
    else:
        pre.insert(pos + 1, real_ans)
        pre.insert(pos, question)

def update_post(ans, real_ans, question, pre, post, pos):
    if (pos > 0):
        for i in range(len(post)):
            if (pre[pos] == post[i]):
                break
        pos = i
        if (ans == 'Y'):
            post.insert(pos + 1, question)
            post.insert(pos, real_ans)
        else:
            post.insert(pos + 1, question)
            post.insert(pos + 1, real_ans)
    else:
        if (ans == 'Y'):
            post.insert(pos + 1, question)
            post.insert(pos - 1, real_ans)
        else:
            post.insert(pos + 1, question)
            post.insert(pos, real_ans)
            
def Search_L(pos, postorder):
    Q_count = 0
    L_count = 0
    for i in range(pos, -len(postorder), -1):
        item = postorder[i]
        if (Is_Q(item)):
            Q_count += 1
        else:
            L_count += 1
        if (L_count == Q_count + 1):
            break
    return i - 1

def Search_R(pos, preorder):
    Q_count = 0
    L_count = 0
    for i in range(pos, len(preorder)):
        item = preorder[i]
        if (Is_Q(item)):
            Q_count += 1
        else:
            L_count += 1
        if (L_count == Q_count + 1):
            break
    return i + 1
        
def Undo_A(S_data, postorder, preorder):
    print('Is the question "' + S_data[-2] + '" where you made a mistake? [Y or N or U]')
    if (S_data[-2] == S_data[0]):
        ans = None
        while not (ans == 'Y' or ans == 'U'):
            ans = input()
    else:
        ans = None
        while not (ans == 'Y' or ans == 'N' or ans == 'U'):
            ans = input()
    if (ans == 'Y'):
        for i in range(-1, -(len(postorder) + 1), -1):
            if (postorder[i] == S_data[-2]):
                break
        pos = i
        S_data.pop()
        S_data.pop()
        AnimalGuess_A(S_data, postorder, preorder, pos)
    elif (ans == 'N'):
        S_data.pop()
        Undo_A(S_data, postorder, preorder)
    else:
        for i in range(-1, -(len(postorder) + 1), -1):
            if (postorder[i] == S_data[-2]):
                break
        pos = i
        S_data.pop()
        S_data.pop()
        AnimalGuess_A(S_data, postorder, preorder, pos)

def Undo_B(S_data, postorder, preorder):
    print('Is the question "' + S_data[-2] + '" where you made a mistake? [Y or N or U]')
    if (S_data[-2] == S_data[0]):
        ans = None
        while not (ans == 'Y' or ans == 'U'):
            ans = input()
    else:
        ans = None
        while not (ans == 'Y' or ans == 'N' or ans == 'U'):
            ans = input()
    if (ans == 'Y'):
        for i in range(0, len(preorder)):
            if (preorder[i] == S_data[-2]):
                break
        pos = i
        S_data.pop()
        S_data.pop()
        AnimalGuess_B(S_data, postorder, preorder, pos)
    elif (ans == 'N'):
        S_data.pop()
        Undo_B(S_data, postorder, preorder)
    else:
        for i in range(0, len(preorder)):
            if (preorder[i] == S_data[-2]):
                break
        pos = i
        S_data.pop()
        S_data.pop()
        AnimalGuess_B(S_data, postorder, preorder, pos)
        
def AnimalGuess_A(S_data, postorder, preorder, pos):
    global flag
    root = postorder[pos]
    S_data.append(root)
    if (Is_Q(root)):
        print(root + " [Y or N or U]")
        if (root == postorder[-1]):
            ans = None
            while not (ans == 'Y' or ans == 'N'):
                ans = input()
        else:
            ans = None
            while not (ans == 'Y' or ans == 'N' or ans == 'U'):
                ans = input()
        if (ans == 'Y'):
            pos = Search_L(pos - 1, postorder)
            AnimalGuess_A(S_data, postorder, preorder, pos)
        elif (ans == 'N'):
            pos -= 1
            AnimalGuess_A(S_data, postorder, preorder, pos)
        else:
            Undo_A(S_data, postorder, preorder)        
    else:
        print("My guess is " + root + ". Am I right? [Y or N or U]")
        ans = None
        while not (ans == 'Y' or ans == 'N' or ans == 'U'):
            ans = input()
        if (ans == 'Y'):
            print("Shall we play again? [Y or N]")
            ans = None
            while not (ans == 'Y' or ans == 'N'):
                ans = input()
            if (ans == 'Y'):
                for i in range(len(S_data)):
                    S_data.pop()
                pos = -1
                flag = True
            else:
                flag = False
        elif (ans == 'N'):
            real_ans = input("I give up. What are you? ")
            print("Please type a yes/no question that will distinguish a " + real_ans + " from a " + root + ".")
            question = input("Your question: ")
            print("As a " + real_ans + ", " + question + " Please answer [Y or N] ")
            ans = None
            while not (ans == 'Y' or ans == 'N'):
                ans = input()
            pre_ref = preorder[:]
            pos_ref = postorder[:]
            update_pre(ans, real_ans, question, preorder, pos_ref, pos)
            update_post(ans, real_ans, question, pre_ref, postorder, pos)
            print("Shall we play again? [Y or N]")
            ans = None
            while not (ans == 'Y' or ans == 'N'):
                ans = input()
            print("Thank you for teaching me a thing or two.")
            if (ans == 'Y'):
                for i in range(len(S_data)):
                    S_data.pop()
                pos = -1
                flag = True
            else:
                flag = False
        else:
            Undo_A(S_data, postorder, preorder)

def AnimalGuess_B(S_data, postorder, preorder, pos):
    global flag
    root = preorder[pos]
    S_data.append(root)
    if (Is_Q(root)):
        print(root + " [Y or N or U]")
        if (root == preorder[0]):
            ans = None
            while not (ans == 'Y' or ans == 'N'):
                ans = input()
        else:
            ans = None
            while not (ans == 'Y' or ans == 'N' or ans == 'U'):
                ans = input()
        if (ans == 'Y'):
            pos += 1
            AnimalGuess_B(S_data, postorder, preorder, pos)
        elif (ans == 'N'):
            pos = Search_R(pos + 1, preorder)
            AnimalGuess_B(S_data, postorder, preorder, pos)
        else:
            Undo_B(S_data, postorder, preorder)
    else:
        print("My guess is " + root + ". Am I right? [Y or N or U]")
        ans = None
        while not (ans == 'Y' or ans == 'N' or ans == 'U'):
            ans = input()
        if (ans == 'Y'):
            print("Shall we play again? [Y or N]")
            ans = None
            while not (ans == 'Y' or ans == 'N'):
                ans = input()
            if (ans == 'Y'):
                for i in range(len(S_data)):
                    S_data.pop()
                pos = 0
                flag = True
            else:
                flag = False
        elif (ans == 'N'):
            real_ans = input("I give up. What are you? ")
            print("Please type a yes/no question that will distinguish a " + real_ans + " from a " + root + ".")
            question = input("Your question: ")
            print("As a " + real_ans + ", " + question + " Please answer [Y or N] ")
            ans = None
            while not (ans == 'Y' or ans == 'N'):
                ans = input()
            pre_ref = preorder[:]
            pos_ref = postorder[:]
            update_pre(ans, real_ans, question, preorder, pos_ref, pos)
            update_post(ans, real_ans, question, pre_ref, postorder, pos)
            print("Shall we play again? [Y or N]")
            ans = None
            while not (ans == 'Y' or ans == 'N'):
                ans = input()
            print("Thank you for teaching me a thing or two.")
            if (ans == 'Y'):
                for i in range(len(S_data)):
                    S_data.pop()
                pos = 0
                flag = True
            else:
                flag = False
        else:
            Undo_B(S_data, postorder, preorder)
    
f = open("data-A.txt", 'r')
dataA = []
for line in f.readlines():
    temp = line.strip().split("\n")
    dataA.append(temp[0])
f.close()
f = open("data-B.txt", 'r')
dataB = []
for line in f.readlines():
    temp = line.strip().split("\n")
    dataB.append(temp[0])
f.close()

save_data = []
data_type = None
while not (data_type == 'A' or data_type == 'B'):
    data_type = input("Choose the Data Type. A or B : ")
if (data_type == 'A'):
    pos = -1
    AnimalGuess_A(save_data, dataA, dataB, pos)
    while flag:
        AnimalGuess_A(save_data, dataA, dataB, pos)
else:
    pos = 0
    AnimalGuess_B(save_data, dataA, dataB, pos)
    while flag:
        AnimalGuess_B(save_data, dataA, dataB, pos)

f = open("data-A.txt", 'w')
for i in range(len(dataA)):
    temp = dataA[i] + "\n"
    data = temp
    f.write(data)
f.close()
f = open("data-B.txt", 'w')
for i in range(len(dataB)):
    temp = dataB[i] + "\n"
    data = temp
    f.write(data)
f.close()

