#include <stdio.h>
#include <stdlib.h>
int** Create_Mat(int*ro, int*col, int Matrixnumber)
{
	int ch;
	int space = 0, enter = 0;
	int row, column;
	int i = 0, j = 0;
	int minus = 0;

	FILE*mat;

	if (Matrixnumber == 1)
	{
		mat = fopen("matrix1.txt", "rt");
	}
	else
	{
		mat = fopen("matrix2.txt", "rt");
	}



	if (mat == NULL)
	{
		puts("���� ���� ����!");
		return -1;
	}
	while ((ch = fgetc(mat)) != EOF)
	{
		if (ch == ' ')
			space++;
		else if (ch == '\n')
			enter++;
	}
	fclose(mat);




	row = enter + 1;
	column = space / row + 1;
	*ro = row;
	*col = column;




	int ** matrix = (int **)malloc(row*sizeof(int*));
	for (i = 0; i < row; i++)
	{
		matrix[i] = (int*)malloc(column*sizeof(int));
	}

	for (i = 0; i < row; i++)
	{
		for (j = 0; j < column; j++)
		{
			matrix[i][j] = 0;
		}
	}




	if (Matrixnumber == 1)
	{
		mat = fopen("matrix1.txt", "rt");
	}
	else
	{
		mat = fopen("matrix2.txt", "rt");
	}



	i = 0;
	j = 0;

	while (1)
	{
		ch = fgetc(mat);
		if (ch == EOF)
		{
			break;
		}
		else if (ch == ' ')
		{
			j++;
		}
		else if (ch == '\n')
		{
			i++;
			j = 0;
		}
		else if (ch == '-')
		{
			minus = 1;
		}
		else
		{
			matrix[i][j] = matrix[i][j] * 10 + ch - '0';
			if (minus == 1)
			{
				matrix[i][j] *= (-1);
				minus = 0;
			}
		}
	}
	fclose(mat);
	return matrix;
}
int main(void)
{
	int row1, column1, row2, column2;
	int i, j;
	int **matrix1, **matrix2;

	matrix1 = Create_Mat(&row1, &column1, 1);
	matrix2 = Create_Mat(&row2, &column2, 2);

	printf("First Matrix (FILE: matrix1.txt)\nSize:%d*%d\n<Elements>\n", row1, column1);

	for (i = 0; i < row1; i++)
	{
		for (j = 0; j < column1; j++)
		{
			printf("\t%d ", matrix1[i][j]);
		}
		printf("\n");
	}
	printf("\n");


	printf("Second Matrix (FILE: matrix2.txt)\nSize: %d*%d\n<Elements>\n", row2, column2);

	for (i = 0; i < row2; i++)
	{
		for (j = 0; j < column2; j++)
		{
			printf("\t%d ", matrix2[i][j]);
		}
		printf("\n");
	}
	printf("\n");


	for (i = 0; i<row1; i++)
		free(matrix1[i]);
	free(matrix1);

	for (i = 0; i<row2; i++)
		free(matrix2[i]);
	free(matrix2);

	return 0;
}