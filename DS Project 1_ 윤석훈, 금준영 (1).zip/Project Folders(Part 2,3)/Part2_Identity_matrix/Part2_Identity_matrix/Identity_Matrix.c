#include <stdio.h>
#include <stdlib.h>
int** Identity_Matrix(int size)
{
	int i, j;
	int** matrix = (int**)malloc(sizeof(int*)*size);
	for (i = 0; i < size; i++)
	{
		matrix[i] = (int*)malloc(sizeof(int)*size);
	}
	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			if (i == j)
			{
				matrix[i][j] = 1;
			}
			else
			{
				matrix[i][j] = 0;
			}
		}
	}
	return matrix;
}
int main(void)
{
	int n;
	int**Id_matrix;
	int i, j;


	printf("Size of Identity Matrix: ");
	scanf("%d", &n);
	Id_matrix = Identity_Matrix(n);
	
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			printf("\t%d", Id_matrix[i][j]);
		}
		printf("\n");
	}
	printf("\n");

	for (i = 0; i < n; i++)
	{
		free(Id_matrix[i]);
	}
	free(Id_matrix);

	return 0;
}