#include <stdio.h>
#include <stdlib.h>
int** Create_Mat(int*ro, int*col, int Matrixnumber)
{
	int ch;
	int space = 0, enter = 0;
	int row, column;
	int i = 0, j = 0;
	int minus = 0;

	FILE*mat;

	if (Matrixnumber == 1)
	{
		mat = fopen("matrix1.txt", "rt");
	}
	else
	{
		mat = fopen("matrix2.txt", "rt");
	}



	if (mat == NULL)
	{
		puts("���� ���� ����!");
		return -1;
	}
	while ((ch = fgetc(mat)) != EOF)
	{
		if (ch == ' ')
			space++;
		else if (ch == '\n')
			enter++;
	}
	fclose(mat);




	row = enter + 1;
	column = space / row + 1;
	*ro = row;
	*col = column;




	int ** matrix = (int **)malloc(row*sizeof(int*));
	for (i = 0; i < row; i++)
	{
		matrix[i] = (int*)malloc(column*sizeof(int));
	}

	for (i = 0; i < row; i++)
	{
		for (j = 0; j < column; j++)
		{
			matrix[i][j] = 0;
		}
	}




	if (Matrixnumber == 1)
	{
		mat = fopen("matrix1.txt", "rt");
	}
	else
	{
		mat = fopen("matrix2.txt", "rt");
	}



	i = 0;
	j = 0;

	while (1)
	{
		ch = fgetc(mat);
		if (ch == EOF)
		{
			break;
		}
		else if (ch == ' ')
		{
			j++;
		}
		else if (ch == '\n')
		{
			i++;
			j = 0;
		}
		else if (ch == '-')
		{
			minus = 1;
		}
		else
		{
			matrix[i][j] = matrix[i][j] * 10 + ch - '0';
			if (minus == 1)
			{
				matrix[i][j] *= (-1);
				minus = 0;
			}
		}
	}
	fclose(mat);
	return matrix;
}

int**Power_Matrix(int**mat1, int row, int column,int n)
{
	int i, j, k, powerloop;
	int prod_sum;
	int ** Powered_Matrix;
	int ** temp_matrix;
	int *** remove_temp;

	if (column != row)
	{
		return -1;
	}
	else if (n < 1)
	{
		return 0;
	}
	else
	{
		Powered_Matrix = (int **)malloc(row*sizeof(int*));
		for (i = 0; i < row; i++)
		{
			Powered_Matrix[i] = (int*)malloc(column*sizeof(int));
		}

		if (n == 1)
		{
			Powered_Matrix = mat1;
			return Powered_Matrix;
		}
		else
		{
			Powered_Matrix = mat1;
			remove_temp = (int***)malloc((n-1)*sizeof(int**));

			for (i = 0; i < row; i++)
			{
				remove_temp[i] = (int**)malloc(row*sizeof(int*));
				for (j = 0; j < column; j++)
				{
					remove_temp[i][j] = (int*)malloc(column*sizeof(int));
				}
			}
			for (powerloop = 2; powerloop <= n; powerloop++)
			{
				temp_matrix = (int **)malloc(row*sizeof(int*));
				for (i = 0; i < row; i++)
				{
					temp_matrix[i] = (int*)malloc(column*sizeof(int));
				}
				for (i = 0; i < row; i++)
				{
					for (j = 0; j < column; j++)
					{
						temp_matrix[i][j] = 0;
					}
				}
				for (i = 0; i < row; i++)
				{
					for (j = 0; j < column; j++)
					{
						prod_sum = 0;
						for (k = 0; k < column; k++)
						{
							prod_sum = Powered_Matrix[i][k] * mat1[k][j];
							temp_matrix[i][j] += prod_sum;
						}
					}
				}
				Powered_Matrix = temp_matrix;
				remove_temp[powerloop] = temp_matrix;		
			}


			for (powerloop = 2; powerloop <= n - 1; powerloop++)
				free(remove_temp[powerloop]);


			return Powered_Matrix;
		}
	}
}
int main(void)
{
	int row1, column1;
	int i, j;
	int **matrix1;
	int **Powered_Matrix;
	int n;


	matrix1 = Create_Mat(&row1, &column1, 1);

	printf("Matrix Given (Matrix1.txt):\n");
	for (i = 0; i < row1; i++)
	{
		for (j = 0; j < column1; j++)
		{
			printf("\t%d", matrix1[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	
	printf("Power degree n(Natural Number):");
	scanf("%d", &n);

	Powered_Matrix = Power_Matrix(matrix1, row1, column1,n);

	if (Powered_Matrix == -1)
	{
		printf("Matrix given is not a square matrix\nPowering Fail\n");
		for (i = 0; i<row1; i++)
			free(matrix1[i]);
		free(matrix1);

		return 0;
	}

	else if (Powered_Matrix == 0)
	{
		printf("n should be natural number\nPowering Fail\n");
		for (i = 0; i<row1; i++)
			free(matrix1[i]);
		free(matrix1);

		return 0;
	}


	printf("Matrix powered by %d:\n",n);
	for (i = 0; i < row1; i++)
	{
		for (j = 0; j < column1; j++)
		{
			printf("\t%d", Powered_Matrix[i][j]);
		}
		printf("\n");
	}
	printf("\n");

	if (n != 1)
	{
		for (i = 0; i < row1; i++)
			free(matrix1[i]);
		free(matrix1);
	}

	for (i = 0; i<row1; i++)
		free(Powered_Matrix[i]);
	free(Powered_Matrix);



	return 0;
}