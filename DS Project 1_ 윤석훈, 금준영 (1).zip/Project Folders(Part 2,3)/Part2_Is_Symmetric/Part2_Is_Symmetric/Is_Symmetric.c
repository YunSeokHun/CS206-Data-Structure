#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#define TRUE 1
#define FALSE 0
int** Create_Mat(int*ro, int*col, int Matrixnumber)
{
	int ch;
	int space = 0, enter = 0;
	int row, column;
	int i = 0, j = 0;
	int minus = 0;

	FILE*mat;

	if (Matrixnumber == 1)
	{
		mat = fopen("matrix1.txt", "rt");
	}
	else
	{
		mat = fopen("matrix2.txt", "rt");
	}



	if (mat == NULL)
	{
		puts("���� ���� ����!");
		return -1;
	}
	while ((ch = fgetc(mat)) != EOF)
	{
		if (ch == ' ')
			space++;
		else if (ch == '\n')
			enter++;
	}
	fclose(mat);




	row = enter + 1;
	column = space / row + 1;
	*ro = row;
	*col = column;




	int ** matrix = (int **)malloc(row*sizeof(int*));
	for (i = 0; i < row; i++)
	{
		matrix[i] = (int*)malloc(column*sizeof(int));
	}

	for (i = 0; i < row; i++)
	{
		for (j = 0; j < column; j++)
		{
			matrix[i][j] = 0;
		}
	}




	if (Matrixnumber == 1)
	{
		mat = fopen("matrix1.txt", "rt");
	}
	else
	{
		mat = fopen("matrix2.txt", "rt");
	}



	i = 0;
	j = 0;

	while (1)
	{
		ch = fgetc(mat);
		if (ch == EOF)
		{
			break;
		}
		else if (ch == ' ')
		{
			j++;
		}
		else if (ch == '\n')
		{
			i++;
			j = 0;
		}
		else if (ch == '-')
		{
			minus = 1;
		}
		else
		{
			matrix[i][j] = matrix[i][j] * 10 + ch - '0';
			if (minus == 1)
			{
				matrix[i][j] *= (-1);
				minus = 0;
			}
		}
	}
	fclose(mat);
	return matrix;
}

int Is_Symmetric(int**matrix, int row, int column)
{
	int i, j;
	if (row != column)
	{
		return FALSE;
	}
	else
	{
		for (i = 0; i < row - 1; i++)
		{
			for (j = i + 1; j < row; j++)
			{
				if (matrix[i][j] != matrix[j][i])
				{
					return FALSE;
				}
			}
		}
		return TRUE;
	}
}

int main(void)
{
	int row1, column1;
	int i, j;
	int **matrix1;

	matrix1 = Create_Mat(&row1, &column1, 1);
	printf("Original Matrix:\n");
	for (i = 0; i < row1; i++)
	{
		for (j = 0; j < column1; j++)
		{
			printf("\t%d", matrix1[i][j]);
		}
		printf("\n");
	}
	printf("\n");

	if(Is_Symmetric(matrix1, row1, column1))
	{
		printf("It's a Symmetric\n");
	}
	else
	{
		printf("It's not a Symmetric\n");
	}

	for (i = 0; i<row1; i++)
		free(matrix1[i]);
	free(matrix1);

	return 0;
}