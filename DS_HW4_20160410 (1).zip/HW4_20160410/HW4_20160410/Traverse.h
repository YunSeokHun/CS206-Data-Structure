#ifndef __TRAVERSE__
#define __TRAVERSE__

typedef char Data;

typedef struct _Tree
{
	Data data;
	struct _Tree * left;
	struct _Tree * right;
}TreeNode;

TreeNode * MakeTreeNode(void);
Data GetData(TreeNode*tree);
void SetData(TreeNode*tree, Data data);

TreeNode * GetLeftSubTree(TreeNode * tree);
TreeNode * GetRightSubTree(TreeNode * tree);

void MakeLeftSubTree(TreeNode * main, TreeNode *sub);
void MakeRightSubTree(TreeNode * main, TreeNode *sub);

void Preorder(TreeNode * tree);
void Postorder(TreeNode * tree);
void DeleteTreeMemory(TreeNode * tree);

#endif