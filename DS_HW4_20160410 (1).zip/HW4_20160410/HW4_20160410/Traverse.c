#include <stdio.h>
#include <stdlib.h>
#include "Traverse.h"

TreeNode * MakeTreeNode(void)
{
	TreeNode * node = (TreeNode*)malloc(sizeof(TreeNode));

	node->left = NULL;
	node->right = NULL;
	return node;
}
Data GetData(TreeNode*tree)
{
	return tree->data;
}
void SetData(TreeNode*tree, Data data)
{
	tree->data = data;
}

TreeNode * GetLeftSubTree(TreeNode * tree)
{
	return tree->left;
}
TreeNode * GetRightSubTree(TreeNode * tree)
{
	return tree->right;
}

void MakeLeftSubTree(TreeNode * Ptree, TreeNode * Ctree)
{
	if (Ptree->left != NULL)
	{
		free(Ptree->left);
	}
	Ptree->left = Ctree;
}
void MakeRightSubTree(TreeNode * Ptree, TreeNode * Ctree)
{
	if (Ptree->right != NULL)
	{
		free(Ptree->right);
	}
	Ptree->right = Ctree;
}

void Preorder(TreeNode * tree)
{
	if (tree == NULL)
	{
		return;
	}

	printf("%c ", tree->data);
	Preorder(tree->left);
	Preorder(tree->right);
}
void Postorder(TreeNode * tree)
{
	if (tree == NULL)
	{
		return;
	}

	Postorder(tree->left);
	Postorder(tree->right);
	printf("%c ", tree->data);
}
void DeleteTreeMemory(TreeNode * tree)
{
	if (tree == NULL)
		return;

	DeleteTreeMemory(tree->left);
	DeleteTreeMemory(tree->right);

	free(tree);
}