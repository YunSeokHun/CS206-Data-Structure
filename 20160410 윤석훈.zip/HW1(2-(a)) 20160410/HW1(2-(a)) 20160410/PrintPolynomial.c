#include<stdio.h>
void PrintPolynomial(char*a)
{
	int i;
	int First_Plus_Expression=0;

	printf("P(X)=");
	for (i = 9; i >= 0; i--)
	{
		if (a[i] != 0)
		{
			if (i >= 2)
			{
				if (a[i] == 1)
				{
					if (First_Plus_Expression == 0)
					{
						First_Plus_Expression++;
						printf("%c", 'X');
					}
					else
					{
						printf("+%c", 'X');
					}
				}
				else if (a[i] == -1)
				{
					if (First_Plus_Expression == 0)
					{
						First_Plus_Expression++;
					}
					printf("-%c", 'X');
				}
				else
				{
					if (a[i] > 0)
					{
						if (First_Plus_Expression == 0)
						{
							printf("%d%c", a[i], 'X');
							First_Plus_Expression++;
						}
						else
						{
							printf("+%d%c", a[i], 'X');
						}
					}
					else
					{
						if (First_Plus_Expression == 0)
						{
							First_Plus_Expression++;
						}
						printf("%d%c", a[i], 'X');
					}
				}
				printf("**%d", i);
			}
			else if (i == 1)
			{
				if (a[i] == 1)
				{
					if (First_Plus_Expression == 0)
					{
						printf("%c", 'X');
						First_Plus_Expression++;
					}
					printf("+%c", 'X');
				}
				else if (a[i] == -1)
				{
					if (First_Plus_Expression == 0)
					{
						First_Plus_Expression++;
					}
					printf("-%c", 'X');
				}
				else
				{
					if (a[i] > 0)
					{
						if (First_Plus_Expression == 0)
						{
							printf("%d%c", a[i], 'X');
							First_Plus_Expression++;
						}
						else
						{
							printf("+%d%c", a[i], 'X');
						}
					}
					else
					{
						if (First_Plus_Expression == 0)
						{
							First_Plus_Expression++;
						}
						printf("%d%c", a[i], 'X');
					}
				}
			}
			else
			{
				if (First_Plus_Expression == 0)
				{
					printf("%d", a[i]);
					First_Plus_Expression++;
				}
				else
				{
					if (a[i] > 0)
					{
						printf("+%d", a[i]);
					}
					else
					{
						printf("%d", a[i]);
					}
				}
			}
		}
	}
	printf("\n");
}