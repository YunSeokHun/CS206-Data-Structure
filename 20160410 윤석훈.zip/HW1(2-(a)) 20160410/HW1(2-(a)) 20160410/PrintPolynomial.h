#ifndef __PRINT_POLYNOMIAL__
#define __PRINT_POLYNOMIAL__

void PrintPolynomial(char*a);

#endif