#include <stdio.h>
#include "InputToArray.h"
#include "PrintPolynomial.h"

int main(void)
{
	char arr[200];
	char a[10] = { 0 };
	int i;
	int PlusIndex;

	printf("Enter a polynomial: ");
	scanf("%s", arr);

	InputToArray(arr,a);
	PrintPolynomial(a);
	printf("\n");
}

