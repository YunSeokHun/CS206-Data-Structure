#ifndef __INPUT_TO_ARRAY__
#define __INPUT_TO_ARRAY__

void InputToArray(char*BeforeArr, char*AfterArr);

#endif