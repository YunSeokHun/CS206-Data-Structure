#include<stdio.h>
#include<string.h>
#include<ctype.h>
void InputToArray(char*BeforeArr, char*AfterArr)
{
	int i, j;
	int b, c, d;
	char letter;
	int strLen = strlen(BeforeArr);
	for (i = 0; i < strLen; i++)
	{
		letter = BeforeArr[i];
		if (letter == '(')
		{
			if (isdigit(BeforeArr[i + 3]))
			{
				c = 0;
				d = 0;
				b = 1;
				while (isdigit(BeforeArr[i + 3 + d]))
				{
					d++;
				}
				for (j = i + d + 2; j >= i + 3; j--)
				{
					c += (BeforeArr[j] - '0') * b;
					b *= 10;
				}
				AfterArr[BeforeArr[i + 1] - '0'] = c;
			}
			else if (BeforeArr[i + 3] == '-')
			{
				c = 0;
				d = 0;
				b = 1;
				while (isdigit(BeforeArr[i + 4 + d]))
				{
					d++;
				}
				for (j = i + d + 3; j >= i + 4; j--)
				{
					c += (BeforeArr[j] - '0') * b;
					b *= 10;
				}
				AfterArr[BeforeArr[i + 1] - '0'] = (-1)*c;
			}
		}
	}
}