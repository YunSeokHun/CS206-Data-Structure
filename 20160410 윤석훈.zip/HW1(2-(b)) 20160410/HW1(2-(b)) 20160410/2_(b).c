#include <stdio.h>
#include "InputToArray.h"
#include "PrintPolynomial.h"

int main(void)
{
	char arr1[200],arr2[200];
	char a[10] = { 0 }, b[10] = { 0 }, c[20] = { 0 };
	char Oper;
	int i,j;


	printf("What Operation?(Enter '+' or '*' or 'D'): ");
	scanf("%c", &Oper);


	switch(Oper)
	{
	case '+':
		printf("Polynomial 1: ");
		scanf("%s", arr1);
		printf("Polynomial 2: ");
		scanf("%s", arr2);

		InputToArray(arr1, a);
		InputToArray(arr2, b);

		for (i = 0; i <=9; i++)
		{
			c[i] = a[i] + b[i];
		}
		PrintPolynomial(c);
		break;
	case '*':
		printf("Polynomial 1: ");
		scanf("%s", arr1);
		printf("Polynomial 2: ");
		scanf("%s", arr2);

		InputToArray(arr1, a);
		InputToArray(arr2, b);

		for (i = 0; i <= 9; i++)
		{
			for (j = 0; j <= 9; j++)
			{
				c[i + j] += a[i] * b[j];
			}
		}

		PrintPolynomial(c);
		break;
	case 'D':
		printf("Polynomial: ");
		scanf("%s", arr1);

		InputToArray(arr1, a);

		for (i = 0; i <= 8; i++)
		{
			c[i] = a[i + 1] * (i + 1);
		}
		PrintPolynomial(c);
		break;
	}
}