from WUG import WUG


a = WUG()

a.addVertex("A")
a.addVertex("B")
a.addVertex("C")
a.addVertex("D")
a.addVertex("E")
a.addEdge("A","B",7)
a.addEdge("B","C",10)
a.addEdge("C","D",15)
a.addEdge("D","E",18)
a.addEdge("E","A",21)
a.addEdge("A","D",22)
a.addEdge("B","E",24)
a.addEdge("C","E",27)

print(a.vertexCount())
print(a.edgeCount())
print(a.getVertices())
a.removeVertex("C")
print(a.isVertex("C"))
print(a.degree("A"))
print(a.getNeighbors("D"))
print(a.isEdge("A", "B"))
print(a.weight("A", "B"))
      
