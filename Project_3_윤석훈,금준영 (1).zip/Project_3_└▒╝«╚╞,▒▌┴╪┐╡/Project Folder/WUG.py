class Vertex:
    def __init__(self, name):
        self.name=name
        self.neighbors={}
        self.degree=0


    def __repr__(self):
        return str(self.neighbors)

class WUG:
    def __init__(self):
        self.vertices={}
        self.num_Of_Edge=0

    def vertexCount(self): 
        return len(self.vertices) 

    def edgeCount(self): 
        return self.num_Of_Edge

    def getVertices(self): 
        return self.vertices

    def addVertex(self,name): 
        new_vertex = Vertex(name)
        self.vertices[name]=new_vertex
        
    def removeVertex(self,name): 
        neighbors = self.getNeighbors(name)
        keys = list(neighbors.keys())[:]
        for key in keys:
            self.removeEdge(name,key)
        del self.vertices[name]
            

    def isVertex(self,name): 
        return name in self.vertices.keys()
    
    def degree(self,vertexName): 
        return self.vertices[vertexName].degree
        

    def getNeighbors(self,vertexName): 
        return self.vertices[vertexName].neighbors

    def addEdge(self,vertexName1,vertexName2,weight): 
        self.vertices[vertexName1].neighbors[vertexName2]=weight
        self.vertices[vertexName2].neighbors[vertexName1]=weight
        self.vertices[vertexName1].degree+=1
        self.vertices[vertexName2].degree+=1
        self.num_Of_Edge+=1
        
        

    def removeEdge(self,vertexName1, vertexName2): 
        del self.vertices[vertexName1].neighbors[vertexName2]
        del self.vertices[vertexName2].neighbors[vertexName1]
        self.vertices[vertexName1].degree-=1
        self.vertices[vertexName2].degree-=1
        self.num_Of_Edge-=1

    def isEdge(self,vertexName1,vertexName2): 
        return (vertexName2 in self.vertices[vertexName1].neighbors)

    def weight(self, vertexName1, vertexName2): 
        if(self.isEdge(vertexName1,vertexName2)):
            return self.vertices[vertexName1].neighbors[vertexName2]
        else:
            return -1
