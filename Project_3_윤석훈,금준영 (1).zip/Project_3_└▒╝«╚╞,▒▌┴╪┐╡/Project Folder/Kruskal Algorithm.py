from WUG import WUG
import operator

G = WUG()

G.addVertex("A")
G.addVertex("B")
G.addVertex("C")
G.addVertex("D")
G.addVertex("E")
G.addEdge("A","B",7)
G.addEdge("B","C",24)
G.addEdge("C","D",15)
G.addEdge("D","E",18)
G.addEdge("E","A",100)
G.addEdge("A","D",7)
G.addEdge("B","E",10)
G.addEdge("C","E",7)

def minSpanTree(graph):
    T = WUG()
    Component = []
    Sorted_E = []
    n = graph.vertexCount()
    temp = graph.getVertices()
    for item in temp:
        T.addVertex(item)
        Component.append(set(item))
        temp_dict = graph.getNeighbors(item)
        sorted_temp = sorted(temp_dict.items(), key = operator.itemgetter(1))
        Sorted_E.extend(sorted_temp)
    Sorted_E = sorted(Sorted_E, key = operator.itemgetter(1))
    while (T.edgeCount() < n-1 and graph.edgeCount() != 0):
        pos = 1
        flag = True
        while flag:
            if (graph.isEdge(Sorted_E[0][0], Sorted_E[pos][0]) and graph.weight(Sorted_E[0][0], Sorted_E[pos][0]) == Sorted_E[0][1]):
                for element in Component:
                    if (Sorted_E[0][0] in element):
                        s_1 = element
                    if (Sorted_E[pos][0] in element):
                        s_2 = element
                if (s_1 == s_2):
                    Sorted_E[pos:pos+1] = []
                    Sorted_E[0:1] = []
                else:
                    T.addEdge(Sorted_E[0][0], Sorted_E[pos][0], Sorted_E[0][1])
                    graph.removeEdge(Sorted_E[0][0], Sorted_E[pos][0])
                    Component.append(s_1.union(s_2))
                    Component.remove(s_1)
                    Component.remove(s_2)
                    Sorted_E[pos:pos+1] = []
                    Sorted_E[0:1] = []
                flag = False
            else:
                pos += 1
    return T.getVertices()

print("Original WUG: ")
print(G.getVertices())
print("Minimum Spanning Tree implemented by WUG: ")
print(minSpanTree(G))
        
    
