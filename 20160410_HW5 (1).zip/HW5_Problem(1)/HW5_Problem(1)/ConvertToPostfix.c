#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "Stack.h"
int Precedence(char op)
{
	switch (op)
	{
	case'+': case'-': return 10;
	case'*': case'/': return 20;
	case'(': return 0;
	}
	return -10;
}
void ConvertToPostfix(char * arr)
{
	int i, Index = 0;
	char letter;
	char popped;
	int formorethan10 = 0;
	char * postfix = (char*)malloc(strlen(arr) + 1);
	memset(postfix, NULL, strlen(arr) + 1);
	Stack opstack;

	Make_Stack(&opstack);

	for (i = 0; i <= strlen(arr) - 1; i++)
	{
		formorethan10 = 0;
		letter = arr[i];
		if (isdigit(letter))
		{
			if (isdigit(arr[i + 1]))
			{
				postfix[Index] = (letter - '0') * 10 + arr[i + 1];
				Index++;
				i++;
				formorethan10++;
			}
			if (formorethan10 != 1)
			{
				postfix[Index] = letter;
				Index++;
			}
		}
		else
		{
			switch (letter)
			{
			case'(':
				Push_Stack(&opstack, letter);
				break;
			case')':
				while (1)
				{
					popped = Pop_Stack(&opstack);
					if (popped == '(')
					{
						break;
					}
					postfix[Index] = popped;
					Index++;
				}
				break;
			case'+': case'-':
			case'*': case'/':
				if (Empty_Stack(&opstack))
				{
					Push_Stack(&opstack, letter);
					break;
				}
				else
				{
					while (Precedence(Peek_Stack(&opstack)) >= Precedence(letter))
					{
						postfix[Index] = Pop_Stack(&opstack);
						Index++;
						if (Empty_Stack(&opstack))
						{
							break;
						}
					}
					Push_Stack(&opstack, letter);
					break;
				}
			}
		}
	}
	while (!Empty_Stack(&opstack))
	{
		postfix[Index] = Pop_Stack(&opstack);
		Index++;
	}
	strcpy(arr, postfix);
	free(postfix);
}