#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "Stack.h"
#include "BinaryTree.h"

BTreeNode * MakeExpTree(char exp[])
{
	Stack stack;
	BTreeNode * pnode;
	
	int expLen = strlen(exp);
	int i;

	Make_Stack(&stack);

	for (i = 0; i < expLen; i++)
	{
		pnode = MakeBTreeNode();
		if (exp[i]!='+' && exp[i]!='-' && exp[i]!='*' && exp[i]!='/')
		{
			SetData(pnode, exp[i] - '0');
		}
		else
		{
			MakeRightSubTree(pnode, Pop_Stack(&stack));
			MakeLeftSubTree(pnode, Pop_Stack(&stack));
			SetData(pnode, exp[i]);
		}
		Push_Stack(&stack, pnode);
	}
	return Pop_Stack(&stack);
}

int EvaluateExpTree(BTreeNode *bt)
{
	int op1, op2;

	if (GetLeftSubTree(bt) == NULL && GetRightSubTree(bt) == NULL)
	{
		return GetData(bt);
	}
	op1 = EvaluateExpTree(GetLeftSubTree(bt));
	op2 = EvaluateExpTree(GetRightSubTree(bt));


	switch (GetData(bt))
	{
	case '+':
		return op1 + op2;
	case '-':
		return op1 - op2;
	case '*':
		return op1*op2;
	case '/':
		if (op2 == 0)
		{
			printf("Dividing by 0 is not allowed\n");
			return -1;
		}
		return op1 / op2;
	}
	return 0;
}