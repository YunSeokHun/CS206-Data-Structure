#ifndef __STACK__
#define __STACK__

#define M 100

typedef struct
{
	int StackArray[M];
	int TopIndex;
}Stack;

void Make_Stack(Stack * pointer_stack);
int Empty_Stack(Stack * pointer_stack);

int Push_Stack(Stack * pointer_stack, int data);
int Pop_Stack(Stack * pointer_stack);
int Peek_Stack(Stack * pointer_stack);

#endif