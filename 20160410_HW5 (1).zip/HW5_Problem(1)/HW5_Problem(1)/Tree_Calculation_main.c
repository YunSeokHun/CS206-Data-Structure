#include <stdio.h>
#include "ExpressionTree.h"

int main(void)
{
	char exp[150];
	printf("�� �Է�: ");
	scanf("%s", exp);
	ConvertToPostfix(exp);

	BTreeNode*eTree = MakeExpTree(exp);
	if (EvaluateExpTree(eTree) == -1)
	{
		return;
	}
	printf("������ ���: %d\n", EvaluateExpTree(eTree));

	return 0;
}