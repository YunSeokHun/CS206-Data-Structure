#ifndef __BINARY_TREE_H__
#define __BINARY_TREE_H__

typedef struct btree
{
	int data;
	struct btree * left;
	struct btree * right;
}BTreeNode;

BTreeNode * MakeBTreeNode(void);
int GetData(BTreeNode * bt);
void SetData(BTreeNode *bt, int data);

BTreeNode * GetLeftSubTree(BTreeNode *bt);
BTreeNode * GetRightSubTree(BTreeNode *bt);

void MakeLeftSubTree(BTreeNode * main, BTreeNode * sub);
void MakeRightSubTree(BTreeNode * main, BTreeNode * sub);

#endif