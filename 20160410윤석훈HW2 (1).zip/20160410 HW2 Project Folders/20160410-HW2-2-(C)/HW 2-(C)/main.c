#include <stdio.h>
#include "PQUEUE.h"
#include <stdlib.h>
#include <string.h>
int main(void)
{
	int a;
	int print_dots = 0;
	char reserve[100];
	char arr[100];
	PQUEUE pqueue;
	MAKE_PQUEUE(&pqueue);

	while (1)
	{
		fputs("�Է�(name,class number): ",stdout);
		fgets(reserve, sizeof(reserve), stdin);
		a = strlen(reserve);
		reserve[a - 1] = NULL;
		int length = strlen(reserve);
		if (reserve[1] == 'o')
		{
			break;
		}
		if (reserve[0] == '.')
		{
			print_dots++;
			continue;
		}
		ENPQUEUE(&pqueue, reserve[length-2]-'0',reserve);
	}
	
	while (!EMPTY_PQUEUE(&pqueue))
	{
		DEPQUEUE(&pqueue, arr);
		printf("%s",arr);
	}
	if (print_dots == 1)
	{
		printf("...");
	}
	printf("\n");
	return 0;
}