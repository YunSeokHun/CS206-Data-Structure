#ifndef __PQUEUE__
#define __PQUEUE__

typedef struct node
{
	int priority;
	char name[100];
	struct node * next_node;
}PQNODE;

typedef struct
{
	PQNODE*FRONT;
}PQUEUE;

void MAKE_PQUEUE(PQUEUE * pointer_pqueue);
int EMPTY_PQUEUE(PQUEUE * pointer_pqueue);

void ENPQUEUE(PQUEUE*pointer_pqueue, int prior, char * reserve);
void DEPQUEUE(PQUEUE*pointer_pqueue,char *reserve);
int PQ_PEEK(PQUEUE*pointer_pqueue);

#endif