#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include "Stack.h"
int PostfixCal(char * cal)
{
	Stack calstack;
	int i;
	int divideby0 = 0;
	int operand1, operand2;
	char letter;
	Make_Stack(&calstack);
	
	for (i = 0; i <= strlen(cal)-1; i++)
	{
			letter = cal[i];
			if (letter!='+' && letter!='-' && letter!='*' && letter!='/')
			{
				Push_Stack(&calstack, letter - '0');
			}
			else
			{
				operand2 = Pop_Stack(&calstack);
				operand1 = Pop_Stack(&calstack);
				switch (letter)
				{
				case'+':
					Push_Stack(&calstack, operand1 + operand2);
					break;
				case'-':
					Push_Stack(&calstack, operand1 - operand2);
					break;
				case'*':
					Push_Stack(&calstack, operand1*operand2);
					break;
				case'/':
					if (operand2 == 0)
					{
						printf("Dividing by 0 is not allowed\n");
						return -1;
					}
					Push_Stack(&calstack, operand1 / operand2);
					break;
				}
			}
	}
	return Pop_Stack(&calstack);
}