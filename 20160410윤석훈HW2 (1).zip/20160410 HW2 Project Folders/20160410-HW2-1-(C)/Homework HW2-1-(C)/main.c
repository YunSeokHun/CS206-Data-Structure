#include<stdio.h>
#include<stdlib.h>
#include "Stack.h"
#include "ConvertToPostfix.h"
#include "PostfixCal.h"
int main(void)
{
	char infix[150];
	printf("�� �Է�: ");
	scanf("%s", infix);
	ConvertToPostfix(infix);
	if (PostfixCal(infix) == -1)
	{
		return;
	}
	printf("%d\n", PostfixCal(infix));

}