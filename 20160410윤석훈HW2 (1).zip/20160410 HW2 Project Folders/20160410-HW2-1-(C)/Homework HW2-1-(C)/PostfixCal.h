#ifndef __Postfix_Cal__
#define __Postfix_Cal__

int PostfixCal(char * cal);

#endif