#include <stdio.h>
#include <stdlib.h>
#include "Stack.h"
int main(void)
{
	int a;
	Stack stack;
	Make_Stack(&stack);
	while (1)
	{
		printf("push what integer?(Quit is '-1'): ");
		scanf("%d", &a);
		if (a == -1)
		{
			break;
		}
		Push_Stack(&stack, a);
	}
	printf("<Stack���� ������ ������>\n");
	while(!Empty_Stack(&stack))
	{
		printf("%d\n", Pop_Stack(&stack));
	}
	return 0;
}