#include <stdio.h>
#include "Stack.h"

void Make_Stack(Stack * pointer_stack)
{
	pointer_stack->TopIndex = -1;
}
int Empty_Stack(Stack * pointer_stack)
{
	if (pointer_stack->TopIndex == -1)
	{
		return 1;
	}
	else
		return 0;
}

int Push_Stack(Stack * pointer_stack, int data)
{
	if (pointer_stack->TopIndex == M - 1)
	{
		printf("Stack is full!\n");
		return 0;
	}
	pointer_stack->StackArray[++(pointer_stack->TopIndex)] = data;
	return 1;
}
int Pop_Stack(Stack * pointer_stack)
{
	if (Empty_Stack(pointer_stack))
	{
		printf("Stack is empty to pop something!\n");
		return 0;
	}
	int Popped_data = pointer_stack->StackArray[pointer_stack->TopIndex];
	pointer_stack->TopIndex -= 1;
	return Popped_data;
}
int Peek_Stack(Stack * pointer_stack)
{
	if (Empty_Stack(pointer_stack))
	{
		printf("Stack is empty to peek something!\n");
		return 0;
	}
	return pointer_stack->StackArray[pointer_stack->TopIndex];
}