#include <stdio.h>
#include "PQUEUE.h"
#include <stdlib.h>
#include <string.h>
int main(void)
{
	int a;
	int cnt = 1;
	int order;
	PQUEUE pqueue;
	MAKE_PQUEUE(&pqueue);

	while (1)
	{
		printf("�Է�(first:1,business:2,economy:3,quit:-1):  ");
		scanf("%d", &a);
		if (a < 0)
		{
			break;
		}
		ENPQUEUE(&pqueue, a, cnt);
		cnt++;
	}
	
	while (!EMPTY_PQUEUE(&pqueue))
	{
		printf("%d", DEPQUEUE(&pqueue, &order));
		printf("(%d��°�� �Էµ� ��)\n", order);
	}
	return 0;
}