#ifndef __PQUEUE__
#define __PQUEUE__

typedef struct node
{
	int priority;
	int inputorder;
	struct node * next_node;
}PQNODE;

typedef struct
{
	PQNODE*FRONT;
}PQUEUE;

void MAKE_PQUEUE(PQUEUE * pointer_pqueue);
int EMPTY_PQUEUE(PQUEUE * pointer_pqueue);

void ENPQUEUE(PQUEUE*pointer_pqueue, int prior, int order);
int DEPQUEUE(PQUEUE*pointer_pqueue, int* order);
int PQ_PEEK(PQUEUE*pointer_pqueue);

#endif