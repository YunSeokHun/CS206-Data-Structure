#include <stdio.h>
#include "PQUEUE.h"
#include <stdlib.h>
#include <string.h>
void MAKE_PQUEUE(PQUEUE * pointer_pqueue)
{
	pointer_pqueue->FRONT = NULL;
}
int EMPTY_PQUEUE(PQUEUE * pointer_pqueue)
{
	if (pointer_pqueue->FRONT == NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void ENPQUEUE(PQUEUE*pointer_pqueue, int prior, int order)
{
	PQNODE* NEWNODE = (PQNODE*)malloc(sizeof(PQNODE));
	NEWNODE->next_node = NULL;
	NEWNODE->priority = prior;
	NEWNODE->inputorder = order;

	if (EMPTY_PQUEUE(pointer_pqueue))
	{
		pointer_pqueue->FRONT = NEWNODE;
	}
	else
	{
		int cnt = 0;
		PQNODE* TEMPNODE1;
	    PQNODE* TEMPNODE2;
		TEMPNODE1 = pointer_pqueue->FRONT;
		while(TEMPNODE1->priority <= prior)
		{
			TEMPNODE2 = TEMPNODE1;
			TEMPNODE1 = TEMPNODE1->next_node;
			cnt++;
			if (TEMPNODE1 == NULL)
			{
				break;
			}
		}
		if (cnt == 0)
		{
			NEWNODE->next_node = pointer_pqueue->FRONT;
			pointer_pqueue->FRONT = NEWNODE;
		}
		else
		{
			TEMPNODE2->next_node = NEWNODE;
			NEWNODE->next_node = TEMPNODE1;
		}
	}
}
int DEPQUEUE(PQUEUE*pointer_pqueue, int* order)
{
	int return_prior;
	PQNODE*Remove = (PQNODE*)malloc(sizeof(PQNODE));

	if (EMPTY_PQUEUE(pointer_pqueue))
	{
		printf("PQUEUE is Empty to delete something!!");
		return -1;
	}

	Remove = pointer_pqueue->FRONT;
	*order = Remove->inputorder;
	return_prior = Remove->priority;
	pointer_pqueue->FRONT = pointer_pqueue->FRONT->next_node;
	free(Remove);
	return return_prior;
}
int PQ_PEEK(PQUEUE*pointer_pqueue)
{
	if (EMPTY_PQUEUE(pointer_pqueue))
	{
		printf("PQUEUE is Empty to peek something!!");
		return -1;
	}
	return pointer_pqueue->FRONT->priority;
}