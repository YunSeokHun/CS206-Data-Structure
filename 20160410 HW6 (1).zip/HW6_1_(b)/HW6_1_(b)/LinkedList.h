#ifndef __LINKED_LIST_H__
#define __LINKED_LIST_H__

typedef int Data;
typedef struct _node
{
	Data data;
	struct _node*next;
}Node;
typedef struct _LinkedList
{
	Node *head;
	Node*cur;
	Node*before;
	int Number_of_data;
}List;

void Make_List(List * plist);
void LInsert(List *plist, Data data);
int LFirst(List * plist, Data* pdata);
int LNext(List * plist, Data* pdata);
Data LRemove(List * plist);
int LCount(List * plist);

#endif