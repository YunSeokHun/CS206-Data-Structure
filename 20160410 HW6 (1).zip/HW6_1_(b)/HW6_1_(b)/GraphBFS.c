#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "GraphBFS.h"
#include "LinkedList.h"
#include "Queue.h"


void Make_Graph(Graph *pGraph, int nv)
{
	int i;
	pGraph->Adj_List = (List*)malloc(sizeof(List)*nv);
	pGraph->Vn = nv;
	pGraph->En = 0;

	for (i = 0; i < nv; i++)
	{
		Make_List(&(pGraph->Adj_List[i]));
	}
	pGraph->visit = (int*)malloc(sizeof(int)*pGraph->Vn);
	memset(pGraph->visit, 0, sizeof(int)*pGraph->Vn);
}

void Delete_Graph(Graph*pGraph)
{
	if (pGraph->Adj_List != NULL)
	{
		free(pGraph->Adj_List);
	}
	if (pGraph->visit != NULL)
	{
		free(pGraph->visit);
	}
}

void Add_Edge(Graph* pGraph, int from_V, int to_V)
{
	LInsert(&(pGraph->Adj_List[from_V]), to_V);
	LInsert(&(pGraph->Adj_List[to_V]), from_V);
	pGraph->En++;
}
void ShowGraphEdgeInfo(Graph*pGraph)
{
	int i;
	int vertex;

	for (i = 0; i < pGraph->Vn; i++)
	{
		printf("%d�� ����� ����: ", i + 1);
		if (LFirst(&(pGraph->Adj_List[i]), &vertex))
		{
			printf("%d ", vertex + 1);
			while (LNext(&(pGraph->Adj_List[i]), &vertex))
			{
				printf("%d ", vertex + 1);
			}
		}
		printf("\n");
	}
}

int VisitVertex(Graph*pGraph, int visitVn)
{
	if (pGraph->visit[visitVn] == 0)
	{
		pGraph->visit[visitVn] = 1;
		printf("%d ", visitVn + 1);
		return 1;
	}
	return 0;
}

void BFS_Vertex(Graph*pGraph, int start_V)
{
	Queue queue;
	int visitV = start_V;
	int nextV;

	Make_Queue(&queue);
	VisitVertex(pGraph, visitV);

	while (LFirst(&(pGraph->Adj_List[visitV]), &nextV) == 1)
	{
		if (VisitVertex(pGraph, nextV) == 1)
		{
			Enqueue(&queue, nextV);
		}
		while (LNext(&(pGraph->Adj_List[visitV]), &nextV) == 1)
		{
			if (VisitVertex(pGraph, nextV) == 1)
			{
				Enqueue(&queue, nextV);
			}
		}
		if (Empty_Queue(&queue) == 1)
		{
			break;
		}
		else
		{
			visitV = Dequeue(&queue);
		}
	}
	memset(pGraph->visit, 0, sizeof(int)*pGraph->Vn);
}