#ifndef __QUEUE__
#define __QUEUE__

#define LEN 100
typedef int Data;

typedef struct queue
{
	int front;
	int rear;
	Data queArray[LEN];
}Queue;

void Make_Queue(Queue * pQueue);

int Empty_Queue(Queue * pQueue);

void EnQueue(Queue*pQueue, Data data);
Data Dequeue(Queue*pQueue);
Data Peek_Queue(Queue*pQueue);

#endif