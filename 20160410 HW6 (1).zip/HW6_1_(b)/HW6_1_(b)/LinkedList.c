#include <stdio.h>
#include "LinkedList.h"
#include <stdlib.h>

void Make_List(List *plist)
{
	plist->head = (Node*)malloc(sizeof(Node));
	plist->head->next = NULL;
	plist->Number_of_data = 0;
}
void LInsert(List * plist, Data data)
{
	Node * newNode = (Node*)malloc(sizeof(Node));
	newNode->data = data;
	newNode->next = plist->head->next;
	plist->head->next = newNode;
	(plist->Number_of_data)++;
}
int LFirst(List* plist, Data* pdata)
{
	if (plist->head->next == NULL)
	{
		return 0;
	}
	plist->before = plist->head;
	plist->cur = plist->head->next;
	*pdata = plist->cur->data;
	return 1;
}
int LNext(List*plist, Data*pdata)
{
	if (plist->cur->next == NULL)
	{
		return 0;
	}
	plist->before = plist->cur;
	plist->cur = plist->cur->next;

	*pdata = plist->cur->data;
	return 1;
}
Data LRemove(List *plist)
{
	Node *rpos = plist->cur;
	Data rdata = rpos->data;

	plist->before->next = plist->cur->next;
	plist->cur = plist->before;

	free(rpos);
	(plist->Number_of_data)--;
	return rdata;
}
int LCount(List*plist)
{
	return plist->Number_of_data;
}