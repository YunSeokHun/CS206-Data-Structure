#include <stdio.h>
#include <stdlib.h>
#include "Queue.h"

void Make_Queue(Queue *pQueue)
{
	pQueue->front = 0;
	pQueue->rear = 0;
}
int Empty_Queue(Queue*pQueue)
{
	if (pQueue->front == pQueue->rear)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int NextIdx(int pos)
{
	if (pos == LEN - 1)
	{
		return 0;
	}
	else
	{
		return pos + 1;
	}
}
void Enqueue(Queue*pQueue, Data data)
{
	if (NextIdx(pQueue->rear) == pQueue->front)
	{
		printf("ť�� á���ϴ�!");
		exit(-1);
	}
	pQueue->rear = NextIdx(pQueue->rear);
	pQueue->queArray[pQueue->rear] = data;
}

Data Dequeue(Queue *pQueue)
{
	if (Empty_Queue(pQueue))
	{
		printf("ť�� ������ϴ�!");
		exit(-1);
	}
	pQueue->front = NextIdx(pQueue->front);
	return pQueue->queArray[pQueue->front];
}
Data Peek_Queue(Queue*pQueue)
{
	if (Empty_Queue(pQueue))
	{
		printf("ť�� ������ϴ�!");
		exit(-1);
	}
	return pQueue->queArray[NextIdx(pQueue->front)];
}










