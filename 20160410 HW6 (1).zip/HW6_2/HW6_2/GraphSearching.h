#ifndef __GRAPH_SEARCHING__
#define __GRAPH_SEARCHING__
#include "LinkedList.h"



typedef struct graph
{
	int Vn;
	int En;
	List * Adj_List;
	int * visit;
}Graph;

void Make_Graph(Graph*pGraph, int nv);

void Delete_Graph(Graph*pGraph);

void Add_Edge(Graph*pGraph, int from_V, int to_V);

void ShowGraphEdgeInfo(Graph*pGraph);

void BFS_Vertex(Graph *pGraph, int start_V);

#endif
